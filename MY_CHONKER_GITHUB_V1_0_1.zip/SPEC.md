Append-only. Reversible. Non-authoritative.
