# My Chonker
An append-only context stack for lossless aggregation

## What is this?
My Chonker collects and stacks context without deciding meaning.
Nothing is overwritten. Nothing is interpreted.

## How it works
![Pipeline Overview](diagrams/pipeline_overview.svg)

## Core Flow
Threads → Papers → Archive → Container → Optional Filters

Generated: 2026-02-05T01:23:46.609761Z
